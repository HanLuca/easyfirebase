from setuptools import setup

setup(
	name='easyfirebase',
	version='1.0.0',
	description='use easy firebase!',
	license='MIT',
	packages=['easyfirebase'],
	author='HanLuca',
	author_email='hanluca2022@gmail.com',
	keywords=[''],
	url='https://github.com/HanLuca/easyfirebase'
)